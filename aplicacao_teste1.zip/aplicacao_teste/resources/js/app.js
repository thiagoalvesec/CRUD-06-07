require('./bootstrap');


alert("foi");
$(function() {
    alert('asdfasdf');
    $('.money').mask('000.000.000.000.000,00', {reverse: true});
});

