<?php $__env->startSection('content'); ?>

	<h3>Categoria</h3>

	<p><a href="<?php echo e(url('categories/create')); ?>" class="btn btn-primary">Criar nova categoria</a></p>

	<table class="table">

		<thead>
			<tr>
				<th>ID</th>
				<th>Nome</th>
				<th>Editar</th>
				<th>Deletar</th>
			</tr>
		</thead>
		
		<tbody>
				<tr>
					<td><?php echo e($category->id); ?></td>
					<td><?php echo e($category->name); ?></td>
					<td>
						<a href="<?php echo e(url('categories/'.$category->id.'/edit')); ?>" class="btn btn-primary">Editar</a>
					</td>
					<td>
						<form action="<?php echo e(url("categories/{$category->id}/delete")); ?>" method="POST">
							<?php echo csrf_field(); ?>
							<?php echo method_field('DELETE'); ?>
							<button class="btn btn-danger" type="submit">Delete</button>
						</form>
					</td>
				</tr>
		</tbody>

	</table>

	<div class="col-sm-12">
		<?php if(session()->get('success')): ?>
		  <div class="alert alert-success">
			<?php echo e(session()->get('success')); ?>  
		  </div>
		<?php endif; ?>
	</div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/aplicacao_teste/resources/views/categories/category.blade.php ENDPATH**/ ?>