<?php $__env->startSection('content'); ?>

	<div class="title">
		<h3 class="mb-0">Categorias</h3>
		<div>Cadastre uma nova categoria</div>
    </div>
    
    <?php echo $__env->make('partials._alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="mt-2">
        <form method="POST" action="<?php echo e(url('categories')); ?>">

            <?php echo method_field($category->id ? 'PUT' : 'POST'); ?>

            <?php echo csrf_field(); ?>

            <input type="hidden" name="id" value="<?php echo e($category->id); ?>"/>

            <div class="form-group">    
                <label for="name">Nome:</label>
                <input type="text" class="form-control" name="name" value="<?php echo e(old('name', $category->name)); ?>" required__/>
            </div>
            
            <a href="<?php echo e(url('categories')); ?>" title="Voltar" class="btn-default">Voltar</a>
            <button type="submit" class="btn btn-primary">
                <?php echo e($category->id ? 'Atualizar' : 'Cadastrar'); ?> Categoria
            </button>
            
        </form>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/victor/Downloads/aplicacao_teste/resources/views/categories/create-edit.blade.php ENDPATH**/ ?>