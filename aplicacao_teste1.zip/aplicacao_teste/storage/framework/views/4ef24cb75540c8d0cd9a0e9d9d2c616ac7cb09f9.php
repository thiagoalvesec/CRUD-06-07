<?php $__env->startSection('content'); ?>

	<h3><?php echo e($title); ?></h3>

	<p><a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary">Criar novo produto</a></p>

	<table class="table">

		<thead>
			<tr>
				<th>ID</th>
				<th>Categoria</th>
				<th>Tamanho</th>
				<th>Cor</th>
				<th>Nome</th>
				<th>Preço</th>
				<th>Qtde</th>
				<th>Descrição</th>
				<th>Data criação</th>
				<th>Data atualização</th>
				<th>Editar</th>
				<th>Deletar</th>
			</tr>
		</thead>
		
		<tbody>
			<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($product->id); ?></td>
					<td><?php echo e($product->category->name); ?></td>
					
					<td><?php echo e($product->size_id ? $product->Size->name: '-'); ?></td>
					<td><?php echo e($product->Color->name); ?></td>
					<td><?php echo e($product->name); ?></td>
					<td><?php echo e($product->price); ?></td>
					<td><?php echo e($product->amount); ?></td>
					<td><?php echo e($product->description); ?></td>
					<td><?php echo e($product->created_at); ?></td>
					<td><?php echo e($product->updated_at); ?></td>
					<td>
						<a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-primary">Editar</a>
						
					</td>
					<td>
						<form action="<?php echo e(route('products.delete', $product->id)); ?>" method="POST">
							<?php echo csrf_field(); ?>
							<?php echo method_field('DELETE'); ?>
							<button class="btn btn-danger" type="submit">Delete</button>
						</form>
					</td>
				</tr>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
		</tbody>

	</table>

	<form action="<?php echo e(url('products')); ?>" method="GET">

		<div id="search">
			<label for="search">Pesquisar: </label><br>
			<input type="text"  name="name" placeholder="Buscar..." value="<?php echo e(Request::get('name')); ?>" />
			<input type="submit" value="Submit" class="btn btn-primary">
		</div>

		
	</form>

	<div class="col-sm-12">
		<?php if(session()->get('success')): ?>
		  <div class="alert alert-success">
			<?php echo e(session()->get('success')); ?>  
		  </div>
		<?php endif; ?>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/aplicacao_teste/resources/views/products/index.blade.php ENDPATH**/ ?>