<?php $__env->startSection('content'); ?>
    <div class="row">

        <div class="col-sm-8 offset-sm-2">

            <h1 class="display-3">Menu</h1>

            <div>
                <a href="<?php echo e(url('products')); ?>"  class="btn btn-primary" style="margin-right: 10px">Listar produtos</a>
                <a href="<?php echo e(url('categories')); ?>" class="btn btn-primary" style="margin-left: 10px">Listar categorias</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>    


<?php echo $__env->make('templates.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/aplicacao_teste/resources/views/welcome.blade.php ENDPATH**/ ?>