<?php $__env->startSection('content'); ?>

	<div class="title">
		<h3 class="mb-0">Categorias</h3>
		<div>Cadastre uma nova categoria</div>
    </div>
    
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>


    <div class="mt-2">
        <form method="POST" action="<?php echo e(url('categories')); ?>">

            <?php echo method_field($category->id ? 'PUT' : 'POST'); ?>

            <?php echo csrf_field(); ?>

            <div class="form-group">    
                <label for="name">Nome:</label>
                <input type="text" class="form-control" name="name" value="<?php echo e($category->name); ?>" required__/>
            </div>
            
            <button type="submit" class="btn btn-primary">
                <?php echo e($category->id ? 'Atualizar categoria' : 'Adicionar categoria'); ?>

            </button>
            
        </form>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/victor/Downloads/aplicacao_teste/resources/views/categories/form.blade.php ENDPATH**/ ?>