<?php $__env->startSection('content'); ?>

	<div class="title">
		<h3 class="mb-0">Categorias</h3>
		<div>Visualize as categorias cadastradas</div>
	</div>

	<?php echo $__env->make('partials._alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<div class="filters mt-4">
		<form method="GET" action="">
			<div class="input-group mb-3">
				<input type="text" class="form-control" name="search" placeholder="Pesquise por algo..." value="<?php echo e(Request::get('search')); ?>">
				<div class="input-group-append">
					<button class="btn btn-outline-secondary" type="submit">Pesquisar</button>
				</div>
			</div>
		</form>
	</div>

	<?php if($categories->count()): ?>

	<table class="table">

		<thead>
			<tr>
				<th>ID</th>
				<th>Nome</th>
				<th>Criação</th>
				<th>Alteração</th>
				<th>Editar</th>
				<th>Deletar</th>
			</tr>
		</thead>
		
		<tbody>

			<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php
					// $cloth
				?>
				<tr>
					<td><?php echo e($category->id); ?></td>
					<td><?php echo e($category->name); ?></td>
					<td><?php echo e($category->created_at ? $category->created_at->format('d/m/Y H:i:s') : '-'); ?>

					<td><?php echo e($category->updated_at ? $category->updated_at->format('d/m/Y H:i:s') : '-'); ?>

					<td>
						<a href="<?php echo e(url('categories/'.$category->id.'/edit')); ?>" class="btn btn-primary">Editar</a>
					</td>
					<td>
						<form action="<?php echo e(url("categories/{$category->id}/delete")); ?>" method="POST">
							<?php echo csrf_field(); ?>
							<?php echo method_field('DELETE'); ?>
							<button class="btn btn-danger" type="submit">Delete</button>
						</form>
					</td>
				</tr>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
		</tbody>

	</table>

	<?php echo e($categories->appends(request()->except('page'))->links()); ?>


	<?php else: ?>
		<div>Nenhuma categoria foi encontrada</div>
	<?php endif; ?>

	<div class="text-right"><a href="<?php echo e(url('categories/create')); ?>" class="btn btn-primary">Criar nova categoria</a></div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/victor/Downloads/aplicacao_teste/resources/views/categories/index.blade.php ENDPATH**/ ?>